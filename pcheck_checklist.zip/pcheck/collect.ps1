﻿# ============================================================
#  특허사무소 개인정보처리업무 점검 - PC 자동수집 스크립트
#  실행: 점검실행.bat (USB에 넣고 더블클릭)  /  PS 5.1 이상, Win10/11
#  결과: reports\pcheck_<PC명>_<사용자>_<일시>.json  (+ 동일 이름 .txt 요약)
#  * 모든 항목은 try/catch 로 감싸져 있어 권한 부족 시에도 중단되지 않고 '확인불가'로 기록됨
# ============================================================
param(
    [string]$OutDir = "",
    [int]$Days = 30
)

$ErrorActionPreference = 'SilentlyContinue'
$ProgressPreference    = 'SilentlyContinue'
try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch {}

$ScriptVersion = '1.0'
$Now  = Get-Date
$From = $Now.AddDays(-$Days)

# ------------------------------------------------------------
#  설정 (기관 환경에 맞게 키워드만 수정하면 됨)
# ------------------------------------------------------------
$Cfg = @{
    # 1-가~다  백신
    V3Keywords        = @('V3', 'AhnLab', '안랩')
    # 1-라  PC환경 관리 프로그램 (기관에서 배포하는 제품명/제조사 키워드)
    PcMgmtKeywords    = @('PC보안', 'PC관리', '내PC지키미', '내 PC 지키미', 'NAC', 'Genian', 'TrustNet', 'SafePC', 'PCFill', 'MyPCKeeper', 'Sapion', 'MetaShield', 'DLP', 'PrivacyGuard', '개인정보', 'Soft Camp', 'SoftCamp', 'Document Security', 'DRM', 'MarkAny', 'Fasoo')
    # 2-가~나  농진원망 접속 프로그램 (VPN / VDI)
    VpnKeywords       = @('VPN', 'VDI', 'Citrix', 'Horizon', 'AnyConnect', 'Cisco Secure Client', 'FortiClient', 'GlobalProtect', 'Secuway', 'SSLVPN', 'Pulse Secure', 'Ivanti', 'Zscaler', 'Check Point', 'Axgate', 'Future Systems', 'WeGuardia', 'MagicLine', 'Tilon', 'Dstation', 'VMware', 'Remote Desktop', 'mstsc')
    # 2-라  원격제어/메신저 등 별도 표시하고 싶은 응용프로그램 키워드
    WatchAppKeywords  = @('TeamViewer', 'AnyDesk', 'Chrome Remote', 'RustDesk', 'Telegram', 'KakaoTalk', '카카오톡', 'Dropbox', 'Google Drive', 'OneDrive', 'MEGA', 'uTorrent', 'BitTorrent', 'qBittorrent', 'Discord')
    # 3-다  문서 파일 확장자 및 개인정보 의심 파일명 키워드
    DocExtensions     = @('*.hwp', '*.hwpx', '*.xls', '*.xlsx', '*.xlsm', '*.doc', '*.docx', '*.ppt', '*.pptx', '*.pdf', '*.csv', '*.txt', '*.zip', '*.7z', '*.egg')
    SensitiveKeywords = @('개인정보', '주민', '명단', '연락처', '출원인', '발명자', '고객', '인적사항', '계좌', '이력서', '위임장', '주소록', '전화번호', '특허', '상표', '디자인', '심판')
    # 3-다  추가 스캔 경로 (예: 'D:\', 'E:\문서')  - 비우면 사용자 프로필 폴더만 스캔
    ExtraScanPaths    = @()
    MaxFiles          = 300
    # 3-라  로그온 실패 임계치 (초과 시 확인필요)
    FailedLogonThreshold = 10
    # QR 결과 전송: 체크리스트 HTML이 호스팅된 주소 (아이패드 카메라로 QR을 찍으면 이 주소가 열림)
    #  - GitHub Pages 등에 점검체크리스트.html 을 올린 뒤 그 주소로 바꾸세요. 예: 'https://계정.github.io/pcheck/'
    ChecklistUrl = 'https://bambabo-cmd.github.io/KOAT-checklist/'
    QrMaxChars   = 1500     # QR 데이터 상한(문자). 초과 시 요약을 자동으로 줄임
    OpenQrPage   = $true    # 수집 후 QR 페이지 자동 열기
}

# ------------------------------------------------------------
#  공통 함수
# ------------------------------------------------------------
function W([string]$m) { Write-Host ("[{0}] {1}" -f (Get-Date -Format 'HH:mm:ss'), $m) }
function D($t) { if ($t) { try { ([datetime]$t).ToString('yyyy-MM-dd HH:mm') } catch { "$t" } } else { '' } }
function Test-Admin {
    try { ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator) } catch { $false }
}
$IsAdmin = Test-Admin

if (-not $OutDir) { $OutDir = Join-Path $PSScriptRoot 'reports' }
try { New-Item -ItemType Directory -Path $OutDir -Force | Out-Null } catch {}

$Report = [ordered]@{
    meta  = [ordered]@{}
    items = [ordered]@{}
}
function Add-Result {
    param([string]$Id, [string]$Name, [string]$Result, [string]$Summary, $Details)
    if ($null -eq $Details) { $Details = @() }
    $Report.items[$Id] = [ordered]@{
        id      = $Id
        name    = $Name
        result  = $Result         # 양호 | 미흡 | 확인필요 | 확인불가
        summary = $Summary
        details = @($Details | ForEach-Object { "$_" } | Select-Object -First 400)
    }
    W ("{0} {1} -> {2} : {3}" -f $Id, $Name, $Result, $Summary)
}
# 권한 부족 등으로 실패했을 때 공통 처리
function Add-Fail { param($Id, $Name, $ErrMsg) Add-Result $Id $Name '확인불가' ("자동확인 실패: " + ("$ErrMsg" -replace "`r|`n", ' ').Substring(0, [Math]::Min(150, ("$ErrMsg").Length))) @() }

# 레지스트리 키 마지막 기록 시각 (USB 마지막 연결 시각 등에 사용)
$regApiLoaded = $false
try {
    $sig = @'
[DllImport("advapi32.dll", CharSet = CharSet.Auto)]
public static extern int RegQueryInfoKey(IntPtr hKey, System.Text.StringBuilder lpClass, ref uint lpcbClass, IntPtr lpReserved,
    out uint lpcSubKeys, out uint lpcbMaxSubKeyLen, out uint lpcbMaxClassLen, out uint lpcValues, out uint lpcbMaxValueNameLen,
    out uint lpcbMaxValueLen, out uint lpcbSecurityDescriptor, out long lpftLastWriteTime);
'@
    Add-Type -MemberDefinition $sig -Name RegApi -Namespace Win32 -ErrorAction Stop
    $regApiLoaded = $true
} catch {}
function Get-RegKeyTime([Microsoft.Win32.RegistryKey]$Key) {
    if (-not $regApiLoaded -or $null -eq $Key) { return $null }
    try {
        $cls = New-Object System.Text.StringBuilder 0
        $len = [uint32]0; $a = [uint32]0; $b = [uint32]0; $c = [uint32]0; $d = [uint32]0; $e = [uint32]0; $f = [uint32]0; $g = [uint32]0
        $ft = [long]0
        $r = [Win32.RegApi]::RegQueryInfoKey($Key.Handle.DangerousGetHandle(), $cls, [ref]$len, [IntPtr]::Zero, [ref]$a, [ref]$b, [ref]$c, [ref]$d, [ref]$e, [ref]$f, [ref]$g, [ref]$ft)
        if ($r -eq 0 -and $ft -gt 0) { return [DateTime]::FromFileTime($ft) }
    } catch {}
    return $null
}

# 설치 프로그램 목록 (HKLM 64/32 + HKCU)
$script:InstalledCache = $null
function Get-InstalledPrograms {
    if ($script:InstalledCache) { return $script:InstalledCache }
    $paths = @(
        'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall',
        'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall',
        'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall'
    )
    $out = @()
    foreach ($p in $paths) {
        Get-ChildItem $p -ErrorAction SilentlyContinue | ForEach-Object {
            $k = $_
            $v = Get-ItemProperty $k.PSPath -ErrorAction SilentlyContinue
            if ($v -and $v.DisplayName) {
                $dt = $null
                if ("$($v.InstallDate)" -match '^\d{8}$') { try { $dt = [datetime]::ParseExact($v.InstallDate, 'yyyyMMdd', $null) } catch {} }
                if (-not $dt) { $dt = Get-RegKeyTime $k }
                $out += [pscustomobject]@{
                    Name        = "$($v.DisplayName)".Trim()
                    Version     = "$($v.DisplayVersion)"
                    Publisher   = "$($v.Publisher)"
                    InstallDate = $dt
                    Location    = "$($v.InstallLocation)"
                }
            }
        }
    }
    $script:InstalledCache = $out | Sort-Object Name -Unique
    return $script:InstalledCache
}
function Find-Programs($list, $keywords) {
    $list | Where-Object { $n = "$($_.Name) $($_.Publisher)"; ($keywords | Where-Object { $n -like "*$_*" }).Count -gt 0 }
}
function Fmt-Program($p) { "{0} {1} ({2}) 설치:{3}" -f $p.Name, $p.Version, $p.Publisher, (D $p.InstallDate) }

# ------------------------------------------------------------
#  메타 정보
# ------------------------------------------------------------
W "수집 시작 (관리자 권한: $IsAdmin, 기간: $($From.ToString('yyyy-MM-dd')) ~ $($Now.ToString('yyyy-MM-dd')))"
try {
    $os = Get-CimInstance Win32_OperatingSystem
    $cs = Get-CimInstance Win32_ComputerSystem
    $ips = @(Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue | Where-Object { $_.IPAddress -notlike '127.*' -and $_.IPAddress -notlike '169.254.*' } | Select-Object -ExpandProperty IPAddress)
    $scriptDrive = ''
    try { $scriptDrive = (Split-Path -Qualifier $PSScriptRoot) } catch {}
    $Report.meta = [ordered]@{
        title         = '특허사무소 개인정보처리업무 점검 - 자동수집 결과'
        scriptVersion = $ScriptVersion
        generatedAt   = D $Now
        periodFrom    = $From.ToString('yyyy-MM-dd')
        periodTo      = $Now.ToString('yyyy-MM-dd')
        days          = $Days
        computer      = $env:COMPUTERNAME
        user          = "$env:USERDOMAIN\$env:USERNAME"
        domain        = "$($cs.Domain)"
        manufacturer  = "$($cs.Manufacturer) $($cs.Model)".Trim()
        os            = "$($os.Caption) $($os.Version) (빌드 $($os.BuildNumber))"
        lastBoot      = D $os.LastBootUpTime
        ip            = ($ips -join ', ')
        isAdmin       = $IsAdmin
        scriptDrive   = $scriptDrive
        note          = if ($IsAdmin) { '관리자 권한으로 수집' } else { '일반 사용자 권한으로 수집 - 보안 이벤트로그/Prefetch/블루투스 레지스트리 등 일부 항목은 확인불가로 표시될 수 있음' }
    }
} catch { $Report.meta = [ordered]@{ generatedAt = D $Now; computer = $env:COMPUTERNAME; user = $env:USERNAME; isAdmin = $IsAdmin; periodFrom = $From.ToString('yyyy-MM-dd'); periodTo = $Now.ToString('yyyy-MM-dd'); days = $Days; scriptVersion = $ScriptVersion } }

# ============================================================
#  1. PC환경 보안프로그램 확인
# ============================================================
$avList = @()
try { $avList = @(Get-CimInstance -Namespace 'root/SecurityCenter2' -ClassName AntiVirusProduct -ErrorAction Stop) } catch {}
$avInfo = @()
foreach ($av in $avList) {
    $hex = '{0:X6}' -f [int]$av.productState
    $enabled  = ($hex.Substring(2, 2) -in @('10', '11'))
    $upToDate = ($hex.Substring(4, 2) -eq '00')
    $avInfo += [pscustomobject]@{ Name = $av.displayName; Enabled = $enabled; UpToDate = $upToDate; State = $hex; Path = $av.pathToSignedProductExe; Updated = $av.timestamp }
}
$v3av = $avInfo | Where-Object { $n = $_.Name; ($Cfg.V3Keywords | Where-Object { $n -like "*$_*" }).Count -gt 0 }
$programs = @()
try { $programs = @(Get-InstalledPrograms) } catch {}
$v3prog = @(Find-Programs $programs $Cfg.V3Keywords)
$v3svc  = @(Get-Service -ErrorAction SilentlyContinue | Where-Object { "$($_.DisplayName) $($_.Name)" -match 'V3|AhnLab|ASD' })
$v3proc = @(Get-Process -ErrorAction SilentlyContinue | Where-Object { $_.ProcessName -match '^(V3|ASD|Ahn|MUpdate)' } | Select-Object -ExpandProperty ProcessName -Unique)

# 1-가 V3 설치 여부
try {
    $det = @()
    $det += ($v3prog | ForEach-Object { "설치프로그램: " + (Fmt-Program $_) })
    $det += ($v3av   | ForEach-Object { "보안센터 등록: {0} (상태코드 {1}) 경로 {2}" -f $_.Name, $_.State, $_.Path })
    $det += ($v3svc  | ForEach-Object { "서비스: {0} [{1}]" -f $_.DisplayName, $_.Status })
    $det += ($v3proc | ForEach-Object { "프로세스: $_" })
    $det += ($avInfo | Where-Object { $_ -notin $v3av } | ForEach-Object { "기타 백신: {0} (사용 {1}, 최신 {2})" -f $_.Name, $_.Enabled, $_.UpToDate })
    if ($v3prog.Count -gt 0 -or $v3av.Count -gt 0 -or $v3svc.Count -gt 0) {
        $nm = if ($v3prog.Count -gt 0) { $v3prog[0].Name + ' ' + $v3prog[0].Version } elseif ($v3av.Count -gt 0) { $v3av[0].Name } else { $v3svc[0].DisplayName }
        Add-Result '1-가' 'V3 설치 여부' '양호' "설치됨: $nm" $det
    } elseif ($avInfo.Count -gt 0) {
        Add-Result '1-가' 'V3 설치 여부' '미흡' ("V3 미설치 (다른 백신: " + (($avInfo | Select-Object -ExpandProperty Name) -join ', ') + ")") $det
    } else {
        Add-Result '1-가' 'V3 설치 여부' '미흡' 'V3 및 등록된 백신 없음' $det
    }
} catch { Add-Fail '1-가' 'V3 설치 여부' $_ }

# 1-나 V3 실시간 검사
try {
    $det = @()
    $running = @($v3svc | Where-Object { $_.Status -eq 'Running' })
    $det += ($v3svc | ForEach-Object { "서비스 {0} = {1}" -f $_.Name, $_.Status })
    $det += ($v3av  | ForEach-Object { "보안센터 실시간보호 = {0}" -f $_.Enabled })
    if ($v3av.Count -gt 0) {
        if (($v3av | Where-Object { $_.Enabled }).Count -gt 0) { Add-Result '1-나' 'V3 실시간 검사 설정' '양호' "실시간 보호 사용 중 (보안센터 기준), 실행 서비스 $($running.Count)개" $det }
        else { Add-Result '1-나' 'V3 실시간 검사 설정' '미흡' '보안센터에서 실시간 보호 꺼짐으로 보고됨' $det }
    } elseif ($v3svc.Count -gt 0) {
        if ($running.Count -gt 0) { Add-Result '1-나' 'V3 실시간 검사 설정' '확인필요' "V3 서비스 실행 중($($running.Count)개)이나 보안센터 정보 없음 - V3 화면에서 실시간 검사 ON 직접 확인" $det }
        else { Add-Result '1-나' 'V3 실시간 검사 설정' '미흡' 'V3 서비스가 실행 중이 아님' $det }
    } else { Add-Result '1-나' 'V3 실시간 검사 설정' '미흡' 'V3 미설치로 실시간 검사 불가' $det }
} catch { Add-Fail '1-나' 'V3 실시간 검사 설정' $_ }

# 1-다 V3 업데이트
try {
    $det = @(); $lastUpd = $null
    foreach ($root in @('HKLM:\SOFTWARE\AhnLab', 'HKLM:\SOFTWARE\WOW6432Node\AhnLab')) {
        Get-ChildItem $root -Recurse -ErrorAction SilentlyContinue | Select-Object -First 60 | ForEach-Object {
            $k = $_
            foreach ($vn in ($k.GetValueNames() | Where-Object { $_ -match 'Update|Engine|Date|Version' })) {
                $val = $k.GetValue($vn)
                if ("$val" -ne '') { $det += "레지스트리 {0}\{1} = {2}" -f $k.Name.Replace('HKEY_LOCAL_MACHINE', 'HKLM'), $vn, ("$val".Substring(0, [Math]::Min(60, "$val".Length))) }
            }
        }
    }
    $dirs = @(Get-ChildItem "$env:ProgramFiles\AhnLab", "${env:ProgramFiles(x86)}\AhnLab" -Directory -ErrorAction SilentlyContinue)
    foreach ($d in $dirs) {
        $newest = Get-ChildItem $d.FullName -Recurse -File -ErrorAction SilentlyContinue | Where-Object { $_.Extension -match '^\.(dat|def|ahn|pat|v3d|dll)$' } | Sort-Object LastWriteTime -Descending | Select-Object -First 1
        if ($newest) { $det += "엔진/패턴 파일 최신 수정: {0} ({1})" -f (D $newest.LastWriteTime), $newest.FullName; if (-not $lastUpd -or $newest.LastWriteTime -gt $lastUpd) { $lastUpd = $newest.LastWriteTime } }
    }
    $det += ($v3av | ForEach-Object { "보안센터 최신상태 = {0}, 타임스탬프 {1}" -f $_.UpToDate, $_.Updated })
    $secUp = ($v3av | Where-Object { $_.UpToDate }).Count -gt 0
    $secOld = ($v3av | Where-Object { -not $_.UpToDate }).Count -gt 0
    if ($v3prog.Count -eq 0 -and $v3av.Count -eq 0 -and $v3svc.Count -eq 0) { Add-Result '1-다' 'V3 실시간 업데이트' '미흡' 'V3 미설치' $det }
    elseif ($secOld) { Add-Result '1-다' 'V3 실시간 업데이트' '미흡' "보안센터에서 최신 아님으로 보고됨 (파일기준 최근 갱신 $(D $lastUpd))" $det }
    elseif ($lastUpd -and $lastUpd -gt $Now.AddDays(-7)) { Add-Result '1-다' 'V3 실시간 업데이트' '양호' "최근 7일 내 엔진/패턴 갱신 확인 ($(D $lastUpd))" $det }
    elseif ($secUp) { Add-Result '1-다' 'V3 실시간 업데이트' '양호' "보안센터 최신 상태 (파일기준 $(D $lastUpd))" $det }
    elseif ($lastUpd) { Add-Result '1-다' 'V3 실시간 업데이트' '확인필요' "엔진 파일 마지막 갱신 $(D $lastUpd) - 7일 초과, V3 화면의 엔진 날짜 직접 확인" $det }
    else { Add-Result '1-다' 'V3 실시간 업데이트' '확인필요' '업데이트 일자를 자동 판별하지 못함 - V3 화면에서 엔진 날짜 확인' $det }
} catch { Add-Fail '1-다' 'V3 실시간 업데이트' $_ }

# 1-라 PC환경 관리 프로그램
try {
    $mg = @(Find-Programs $programs $Cfg.PcMgmtKeywords)
    $mgSvc = @(Get-Service -ErrorAction SilentlyContinue | Where-Object { $n = "$($_.DisplayName) $($_.Name)"; ($Cfg.PcMgmtKeywords | Where-Object { $n -like "*$_*" }).Count -gt 0 })
    $det = @($mg | ForEach-Object { "설치프로그램: " + (Fmt-Program $_) }) + @($mgSvc | ForEach-Object { "서비스: {0} [{1}]" -f $_.DisplayName, $_.Status })
    if ($mg.Count -gt 0 -or $mgSvc.Count -gt 0) { Add-Result '1-라' 'PC환경 관리 프로그램 설치' '양호' ("확인됨: " + ((@($mg | ForEach-Object { $_.Name }) + @($mgSvc | ForEach-Object { $_.DisplayName }) | Select-Object -Unique) -join ', ')) $det }
    else { Add-Result '1-라' 'PC환경 관리 프로그램 설치' '미흡' "설정된 키워드($($Cfg.PcMgmtKeywords.Count)개)에 해당하는 관리 프로그램 없음 - collect.ps1 상단 PcMgmtKeywords 에 기관 제품명 추가 필요" $det }
} catch { Add-Fail '1-라' 'PC환경 관리 프로그램 설치' $_ }

# ============================================================
#  2. 응용프로그램 사용여부 확인
# ============================================================
$vpnProgs = @()
try {
    $vpnProgs = @(Find-Programs $programs $Cfg.VpnKeywords)
    $vpnConn  = @(Get-VpnConnection -ErrorAction SilentlyContinue) + @(Get-VpnConnection -AllUserConnection -ErrorAction SilentlyContinue)
    $det = @($vpnProgs | ForEach-Object { "설치프로그램: " + (Fmt-Program $_) }) + @($vpnConn | ForEach-Object { "Windows VPN 프로필: {0} -> {1} [{2}]" -f $_.Name, $_.ServerAddress, $_.ConnectionStatus })
    if ($vpnProgs.Count -gt 0 -or $vpnConn.Count -gt 0) { Add-Result '2-가' '농진원망 접속 프로그램(VPN, VDI) 설치' '양호' ("확인됨: " + ((@($vpnProgs | ForEach-Object { $_.Name }) + @($vpnConn | ForEach-Object { $_.Name })) -join ', ')) $det }
    else { Add-Result '2-가' '농진원망 접속 프로그램(VPN, VDI) 설치' '확인필요' '설정 키워드에 해당하는 VPN/VDI 프로그램 및 Windows VPN 프로필 없음 (웹 기반 VDI 사용 시 브라우저 접속내역으로 확인)' $det }
} catch { Add-Fail '2-가' '농진원망 접속 프로그램(VPN, VDI) 설치' $_ }

# 2-나 이용 여부 (최근 기간)
try {
    $det = @(); $evidence = 0
    # (1) 실행 중 프로세스
    $procs = @(Get-Process -ErrorAction SilentlyContinue | Where-Object { $n = "$($_.ProcessName) $($_.Description)"; ($Cfg.VpnKeywords | Where-Object { $n -like "*$_*" }).Count -gt 0 } | Select-Object -ExpandProperty ProcessName -Unique)
    foreach ($p in $procs) { $det += "현재 실행 중: $p"; $evidence++ }
    # (2) Prefetch (관리자 필요)
    $pfOk = $false
    try {
        $pfs = @(Get-ChildItem "$env:SystemRoot\Prefetch\*.pf" -Force -ErrorAction Stop | Where-Object { $_.LastWriteTime -ge $From })
        $pfOk = $true
        foreach ($pf in $pfs) { $n = $pf.Name; if (($Cfg.VpnKeywords | Where-Object { $n -like "*$_*" }).Count -gt 0) { $det += "Prefetch 실행흔적: {0} 최근실행 {1}" -f $pf.Name, (D $pf.LastWriteTime); $evidence++ } }
    } catch { $det += "Prefetch 조회 불가 (관리자 권한 필요)" }
    # (3) RasClient VPN 연결 이벤트 (Application 로그, 일반 권한 가능)
    try {
        $ras = @(Get-WinEvent -FilterHashtable @{ LogName = 'Application'; ProviderName = 'RasClient'; StartTime = $From } -ErrorAction Stop | Where-Object { $_.Id -in 20221, 20222, 20223, 20225, 20226 })
        if ($ras.Count -gt 0) { $det += "Windows VPN(RasClient) 이벤트 $($ras.Count)건, 최근 $(D $ras[0].TimeCreated)"; $evidence++ }
        $ras | Select-Object -First 10 | ForEach-Object { $det += "  {0} ID{1} {2}" -f (D $_.TimeCreated), $_.Id, (("$($_.Message)" -replace '\s+', ' ').Substring(0, [Math]::Min(90, "$($_.Message)".Length))) }
    } catch {}
    # (4) 설치 폴더의 로그/실행파일 최근 수정
    foreach ($vp in $vpnProgs) {
        if ($vp.Location -and (Test-Path $vp.Location)) {
            $recent = Get-ChildItem $vp.Location -Recurse -File -ErrorAction SilentlyContinue | Where-Object { $_.Extension -match '^\.(log|txt|dat|db)$' -and $_.LastWriteTime -ge $From } | Sort-Object LastWriteTime -Descending | Select-Object -First 1
            if ($recent) { $det += "{0} 로그 최근 기록 {1} ({2})" -f $vp.Name, (D $recent.LastWriteTime), $recent.Name; $evidence++ }
        }
    }
    # (5) 원격 데스크톱 접속 서버 목록 (VDI 대체 확인)
    $rdp = @(Get-ChildItem 'HKCU:\SOFTWARE\Microsoft\Terminal Server Client\Servers' -ErrorAction SilentlyContinue | ForEach-Object { $_.PSChildName })
    if ($rdp.Count -gt 0) { $det += "원격데스크톱 접속 이력 서버: " + ($rdp -join ', ') }
    if ($evidence -gt 0) { Add-Result '2-나' '농진원망 접속 프로그램(VPN, VDI) 이용' '양호' "최근 $Days일 내 이용 흔적 $evidence건 확인" $det }
    elseif ($vpnProgs.Count -eq 0) { Add-Result '2-나' '농진원망 접속 프로그램(VPN, VDI) 이용' '확인필요' 'VPN/VDI 프로그램 미확인 - 이용 방식 담당자 확인' $det }
    else { Add-Result '2-나' '농진원망 접속 프로그램(VPN, VDI) 이용' '확인필요' ("설치되어 있으나 최근 $Days일 이용 흔적을 찾지 못함" + $(if (-not $pfOk) { ' (Prefetch 미확인)' })) $det }
} catch { Add-Fail '2-나' '농진원망 접속 프로그램(VPN, VDI) 이용' $_ }

# 2-다 그 밖의 인터넷 사이트 접속
try {
    $det = @(); $tally = @{}; $histFiles = @()
    $hist = @(
        @{ B = 'Chrome';  P = "$env:LOCALAPPDATA\Google\Chrome\User Data\*\History" },
        @{ B = 'Edge';    P = "$env:LOCALAPPDATA\Microsoft\Edge\User Data\*\History" },
        @{ B = 'Whale';   P = "$env:LOCALAPPDATA\Naver\Naver Whale\User Data\*\History" },
        @{ B = 'Brave';   P = "$env:LOCALAPPDATA\BraveSoftware\Brave-Browser\User Data\*\History" },
        @{ B = 'Firefox'; P = "$env:APPDATA\Mozilla\Firefox\Profiles\*\places.sqlite" }
    )
    foreach ($h in $hist) {
        foreach ($f in @(Get-ChildItem $h.P -ErrorAction SilentlyContinue)) {
            $histFiles += "{0}: 마지막 기록 {1} ({2:N0} KB)" -f $h.B, (D $f.LastWriteTime), ($f.Length / 1KB)
            $tmp = Join-Path $env:TEMP ("hist_" + [guid]::NewGuid().ToString('N') + ".db")
            try {
                Copy-Item $f.FullName $tmp -Force -ErrorAction Stop
                $txt = [IO.File]::ReadAllText($tmp, [Text.Encoding]::GetEncoding('ISO-8859-1'))
                foreach ($m in [regex]::Matches($txt, 'https?://([a-z0-9][a-z0-9\.\-]{2,80})')) {
                    $dm = $m.Groups[1].Value.ToLower(); $key = "$($h.B)|$dm"
                    if ($tally.ContainsKey($key)) { $tally[$key]++ } else { $tally[$key] = 1 }
                }
            } catch { $histFiles += "  $($h.B) 기록 파일 읽기 실패: $_" }
            Remove-Item $tmp -Force -ErrorAction SilentlyContinue
        }
    }
    $det += $histFiles
    $top = $tally.GetEnumerator() | Sort-Object Value -Descending | Select-Object -First 60
    if ($top) { $det += "--- 접속 도메인 상위 (URL 기록 개수, 기간 구분 없음) ---"; $det += ($top | ForEach-Object { "{0,-8} {1}  x{2}" -f $_.Key.Split('|')[0], $_.Key.Split('|')[1], $_.Value }) }
    # DNS 캐시 (현재 세션 접속 흔적)
    $dns = @(Get-DnsClientCache -ErrorAction SilentlyContinue | Where-Object { $_.Entry -notmatch '\.local$|in-addr|_tcp|_udp' } | Select-Object -ExpandProperty Entry -Unique | Select-Object -First 40)
    if ($dns.Count -gt 0) { $det += "--- DNS 캐시 (현재 세션) ---"; $det += $dns }
    $domCount = ($tally.Keys | ForEach-Object { $_.Split('|')[1] } | Select-Object -Unique).Count
    if ($histFiles.Count -eq 0) { Add-Result '2-다' '그 밖의 인터넷 사이트 접속' '양호' '브라우저 방문기록 파일 없음' $det }
    elseif ($domCount -eq 0) { Add-Result '2-다' '그 밖의 인터넷 사이트 접속' '양호' '방문기록 파일은 있으나 추출된 도메인 없음' $det }
    else { Add-Result '2-다' '그 밖의 인터넷 사이트 접속' '확인필요' "브라우저 $($histFiles.Count)개 프로필, 접속 도메인 $domCount종 - 업무 외 사이트 여부 상세목록 확인" $det }
} catch { Add-Fail '2-다' '그 밖의 인터넷 사이트 접속' $_ }

# 2-라 그 밖의 응용프로그램 설치/사용
try {
    $det = @()
    $newP = @($programs | Where-Object { $_.InstallDate -and $_.InstallDate -ge $From } | Sort-Object InstallDate -Descending)
    $watch = @(Find-Programs $programs $Cfg.WatchAppKeywords)
    if ($newP.Count -gt 0) { $det += "--- 최근 $Days일 내 설치 ($($newP.Count)건) ---"; $det += ($newP | ForEach-Object { Fmt-Program $_ }) }
    if ($watch.Count -gt 0) { $det += "--- 주의 프로그램 (원격제어/메신저/클라우드/P2P) ---"; $det += ($watch | ForEach-Object { Fmt-Program $_ }) }
    $userProcs = @(Get-Process -ErrorAction SilentlyContinue | Where-Object { $_.Path -and $_.Path -notlike "$env:SystemRoot*" } | Select-Object -ExpandProperty ProcessName -Unique | Sort-Object)
    if ($userProcs.Count -gt 0) { $det += "--- 현재 실행 중 (Windows 외, $($userProcs.Count)개) ---"; $det += ($userProcs -join ', ') }
    $det += "--- 전체 설치 프로그램 ($($programs.Count)개) ---"; $det += ($programs | ForEach-Object { Fmt-Program $_ })
    if ($newP.Count -gt 0 -or $watch.Count -gt 0) { Add-Result '2-라' '그 밖의 응용프로그램 설치/사용' '확인필요' "최근 설치 $($newP.Count)건, 주의 프로그램 $($watch.Count)건 (전체 $($programs.Count)개)" $det }
    else { Add-Result '2-라' '그 밖의 응용프로그램 설치/사용' '양호' "최근 $Days일 내 신규 설치 없음, 주의 프로그램 없음 (전체 $($programs.Count)개)" $det }
} catch { Add-Fail '2-라' '그 밖의 응용프로그램 설치/사용' $_ }

# ============================================================
#  3. 보안설정, 개인정보취급업무 관련
# ============================================================
# 3-가 USB 사용 흔적
try {
    $det = @(); $recent = @()
    # 점검용 USB(본 스크립트가 든 드라이브)의 시리얼 - 결과에서 구분 표시
    $mySerial = ''
    try { $dl = ($Report.meta.scriptDrive -replace ':', ''); if ($dl) { $mySerial = "$((Get-Partition -DriveLetter $dl -ErrorAction Stop | Get-Disk -ErrorAction Stop).SerialNumber)".Trim() } } catch {}
    $usbRoot = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey('SYSTEM\CurrentControlSet\Enum\USBSTOR')
    if ($usbRoot) {
        foreach ($devName in $usbRoot.GetSubKeyNames()) {
            $dev = $usbRoot.OpenSubKey($devName)
            foreach ($ser in $dev.GetSubKeyNames()) {
                $sk = $dev.OpenSubKey($ser)
                $friendly = "$($sk.GetValue('FriendlyName'))"; if (-not $friendly) { $friendly = $devName }
                $t = Get-RegKeyTime $sk
                $isMine = ($mySerial -and $ser -like "*$mySerial*")
                $line = "{0} | 시리얼 {1} | 마지막 연결(추정) {2}{3}" -f $friendly, $ser, (D $t), $(if ($isMine) { ' ← 점검용 USB' })
                $det += $line
                if ($t -and $t -ge $From -and -not $isMine) { $recent += $line }
            }
        }
    } else { $det += 'USBSTOR 레지스트리 접근 불가' }
    # 휴대폰 등 MTP/WPD 장치
    $wpd = Get-ChildItem 'HKLM:\SOFTWARE\Microsoft\Windows Portable Devices\Devices' -ErrorAction SilentlyContinue
    foreach ($w in $wpd) { $fn = "$((Get-ItemProperty $w.PSPath).FriendlyName)"; $t = Get-RegKeyTime $w; $line = "휴대장치(MTP): {0} | {1} | {2}" -f $fn, ($w.PSChildName.Substring(0, [Math]::Min(50, $w.PSChildName.Length))), (D $t); $det += $line; if ($t -and $t -ge $From) { $recent += $line } }
    # 장치 연결 이벤트 (기본 비활성 로그이나 활성 시 유용)
    try { $ev = @(Get-WinEvent -FilterHashtable @{ LogName = 'Microsoft-Windows-DriverFrameworks-UserMode/Operational'; Id = 2003; StartTime = $From } -ErrorAction Stop); if ($ev.Count -gt 0) { $det += "장치 연결 이벤트(2003) $($ev.Count)건, 최근 $(D $ev[0].TimeCreated)" } } catch {}
    if ($recent.Count -gt 0) { Add-Result '3-가' 'USB 사용 흔적' '확인필요' "최근 $Days일 내 연결된 이동식 저장장치 $($recent.Count)건 (점검용 USB 제외) - 사용 사유 확인" (@("--- 최근 연결 ---") + $recent + @("--- 전체 이력 ---") + $det) }
    else { Add-Result '3-가' 'USB 사용 흔적' '양호' "최근 $Days일 내 연결된 이동식 저장장치 없음 (전체 이력 $($det.Count)건)" $det }
} catch { Add-Fail '3-가' 'USB 사용 흔적' $_ }

# 3-나 와이파이/블루투스
try {
    $det = @(); $recent = @()
    # 무선 프로필 목록
    $profiles = @(netsh wlan show profiles 2>$null | Select-String ':\s*(.+)$' | ForEach-Object { $_.Matches[0].Groups[1].Value.Trim() } | Where-Object { $_ -and $_ -notmatch '^\s*$' })
    if ($profiles.Count -gt 0) { $det += "저장된 Wi-Fi 프로필 ($($profiles.Count)개): " + ($profiles -join ', ') }
    # NetworkList (마지막 연결 시각)
    $nl = @(Get-ChildItem 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\NetworkList\Profiles' -ErrorAction SilentlyContinue)
    if ($nl.Count -eq 0) { $det += 'NetworkList 레지스트리 접근 불가 (관리자 권한 시 마지막 연결시각 확인 가능)' }
    foreach ($k in $nl) {
        $p = Get-ItemProperty $k.PSPath
        $b = $p.DateLastConnected; $lc = $null
        if ($b -and $b.Length -ge 14) { try { $lc = Get-Date -Year ([BitConverter]::ToUInt16($b, 0)) -Month ([BitConverter]::ToUInt16($b, 2)) -Day ([BitConverter]::ToUInt16($b, 6)) -Hour ([BitConverter]::ToUInt16($b, 8)) -Minute ([BitConverter]::ToUInt16($b, 10)) -Second 0 } catch {} }
        $type = switch ([int]$p.NameType) { 71 { 'Wi-Fi' } 6 { '유선' } 23 { 'VPN' } default { "기타($($p.NameType))" } }
        $line = "{0}: {1} | 마지막 연결 {2}" -f $type, $p.ProfileName, (D $lc)
        $det += $line
        if ($type -eq 'Wi-Fi' -and $lc -and $lc -ge $From) { $recent += $line }
    }
    # WLAN 연결 이벤트
    try {
        $wl = @(Get-WinEvent -FilterHashtable @{ LogName = 'Microsoft-Windows-WLAN-AutoConfig/Operational'; Id = 8001; StartTime = $From } -ErrorAction Stop)
        if ($wl.Count -gt 0) {
            $ssids = $wl | ForEach-Object { if ("$($_.Message)" -match 'SSID:\s*(.+)') { $Matches[1].Trim() } } | Group-Object | Sort-Object Count -Descending
            $det += "Wi-Fi 연결 이벤트(8001) 최근 $Days일 $($wl.Count)건: " + (($ssids | ForEach-Object { "$($_.Name)($($_.Count))" }) -join ', ')
            foreach ($s in $ssids) { $recent += "Wi-Fi 연결이벤트: $($s.Name) $($s.Count)회" }
        }
    } catch {}
    # 무선 어댑터 상태
    $wifiAdp = @(Get-NetAdapter -ErrorAction SilentlyContinue | Where-Object { $_.PhysicalMediaType -match '802\.11|Native' -or $_.Name -match 'Wi-?Fi|무선' })
    foreach ($a in $wifiAdp) { $det += "무선 어댑터: {0} [{1}]" -f $a.InterfaceDescription, $a.Status }
    # 블루투스 장치
    $bt = @(Get-PnpDevice -Class Bluetooth -ErrorAction SilentlyContinue | Where-Object { $_.Status -eq 'OK' -and $_.FriendlyName -notmatch 'Adapter|Radio|Enumerator|Microsoft|Generic|RFCOMM|Service|Protocol|Transport|Wireless Bluetooth|Intel|Realtek|Qualcomm|Broadcom|Device Information|Attribute|Personal Area|LE ' })
    if ($bt.Count -gt 0) { $det += "블루투스 연결/페어링 장치 ($($bt.Count)개): " + (($bt | ForEach-Object { $_.FriendlyName }) -join ', ') }
    try {
        $btk = Get-ChildItem 'HKLM:\SYSTEM\CurrentControlSet\Services\BTHPORT\Parameters\Devices' -ErrorAction Stop
        foreach ($k in $btk) {
            $p = Get-ItemProperty $k.PSPath; $nm = ''
            if ($p.Name) { $nm = [Text.Encoding]::UTF8.GetString($p.Name).TrimEnd([char]0) }
            $lcn = $null; if ($p.LastConnected) { try { $lcn = [DateTime]::FromFileTime([BitConverter]::ToInt64($p.LastConnected, 0)) } catch {} }
            $lsn = $null; if ($p.LastSeen) { try { $lsn = [DateTime]::FromFileTime([BitConverter]::ToInt64($p.LastSeen, 0)) } catch {} }
            $line = "블루투스 페어링: {0} ({1}) 마지막연결 {2} 마지막감지 {3}" -f $nm, $k.PSChildName, (D $lcn), (D $lsn)
            $det += $line
            if (($lcn -and $lcn -ge $From) -or ($lsn -and $lsn -ge $From)) { $recent += $line }
        }
    } catch { $det += "블루투스 페어링 레지스트리 조회 불가 (관리자 권한 필요)"; if ($bt.Count -gt 0) { $recent += "블루투스 장치 $($bt.Count)개 확인됨 (연결 시각 미확인)" } }
    if ($recent.Count -gt 0) { Add-Result '3-나' '와이파이, 블루투스 접속 흔적' '확인필요' "최근 $Days일 내 Wi-Fi/블루투스 접속 흔적 $($recent.Count)건" (@('--- 최근 흔적 ---') + $recent + @('--- 전체 ---') + $det) }
    elseif ($profiles.Count -gt 0 -or $bt.Count -gt 0) { Add-Result '3-나' '와이파이, 블루투스 접속 흔적' '확인필요' "최근 접속 흔적 없음이나 Wi-Fi 프로필 $($profiles.Count)개 / 블루투스 장치 $($bt.Count)개 존재" $det }
    else { Add-Result '3-나' '와이파이, 블루투스 접속 흔적' '양호' 'Wi-Fi 프로필 및 블루투스 장치 없음' $det }
} catch { Add-Fail '3-나' '와이파이, 블루투스 접속 흔적' $_ }

# 3-다 파일 다운로드 및 문서 파일
try {
    $det = @(); $files = @()
    $roots = @("$env:USERPROFILE\Desktop", "$env:USERPROFILE\Downloads", "$env:USERPROFILE\Documents", "$env:PUBLIC\Desktop", "$env:PUBLIC\Documents") + @(Get-ChildItem $env:USERPROFILE -Directory -ErrorAction SilentlyContinue | Where-Object { $_.Name -like 'OneDrive*' } | ForEach-Object { $_.FullName }) + @($Cfg.ExtraScanPaths)
    $roots = $roots | Where-Object { $_ -and (Test-Path $_) } | Select-Object -Unique
    foreach ($r in $roots) {
        $files += Get-ChildItem $r -Recurse -File -Include $Cfg.DocExtensions -ErrorAction SilentlyContinue | Where-Object { $_.LastWriteTime -ge $From -or $_.CreationTime -ge $From }
    }
    $files = $files | Sort-Object LastWriteTime -Descending | Select-Object -Unique
    $byExt = $files | Group-Object Extension | Sort-Object Count -Descending
    $sens = @($files | Where-Object { $n = $_.Name; ($Cfg.SensitiveKeywords | Where-Object { $n -like "*$_*" }).Count -gt 0 })
    # 인터넷에서 다운로드된 파일 (Zone.Identifier)
    $dl = @()
    foreach ($f in @(Get-ChildItem "$env:USERPROFILE\Downloads" -Recurse -File -ErrorAction SilentlyContinue | Where-Object { $_.LastWriteTime -ge $From })) {
        try { $z = Get-Content -LiteralPath $f.FullName -Stream Zone.Identifier -ErrorAction Stop; if ($z -match 'ZoneId=3') { $src = ($z | Where-Object { $_ -match '^HostUrl=' }) -replace '^HostUrl=', ''; $dl += "{0} | {1} | {2}" -f (D $f.LastWriteTime), $f.Name, $src } } catch {}
    }
    $det += "스캔 경로: " + ($roots -join '; ')
    $det += "최근 $Days일 문서파일 $($files.Count)건: " + (($byExt | ForEach-Object { "$($_.Name) $($_.Count)" }) -join ', ')
    if ($dl.Count -gt 0) { $det += "--- 인터넷 다운로드 파일 ($($dl.Count)건, 최근 $Days일) ---"; $det += ($dl | Select-Object -First 100) }
    if ($sens.Count -gt 0) { $det += "--- 개인정보 의심 파일명 ($($sens.Count)건) ---"; $det += ($sens | Select-Object -First 100 | ForEach-Object { "{0} | {1} | {2:N0}KB" -f (D $_.LastWriteTime), $_.FullName, ($_.Length / 1KB) }) }
    $det += "--- 최근 문서파일 목록 (최대 $($Cfg.MaxFiles)건) ---"
    $det += ($files | Select-Object -First $Cfg.MaxFiles | ForEach-Object { "{0} | {1} | {2:N0}KB" -f (D $_.LastWriteTime), $_.FullName, ($_.Length / 1KB) })
    if ($sens.Count -gt 0) { Add-Result '3-다' '파일다운로드 및 스토리지 내 특정 파일 유무' '확인필요' "최근 $Days일 문서 $($files.Count)건 중 개인정보 의심 파일명 $($sens.Count)건, 인터넷 다운로드 $($dl.Count)건" $det }
    elseif ($files.Count -gt 0) { Add-Result '3-다' '파일다운로드 및 스토리지 내 특정 파일 유무' '확인필요' "최근 $Days일 문서파일 $($files.Count)건, 인터넷 다운로드 $($dl.Count)건 - 개인정보 포함 여부 확인" $det }
    else { Add-Result '3-다' '파일다운로드 및 스토리지 내 특정 파일 유무' '양호' "최근 $Days일 내 생성/수정된 문서파일 없음" $det }
} catch { Add-Fail '3-다' '파일다운로드 및 스토리지 내 특정 파일 유무' $_ }

# 3-라 윈도우 이벤트로그
try {
    $det = @(); $flags = @()
    function CountEv($log, $ids) { try { @(Get-WinEvent -FilterHashtable @{ LogName = $log; Id = $ids; StartTime = $From } -ErrorAction Stop) } catch { if ("$_" -match 'No events|이벤트가 없') { @() } else { throw } } }
    # System
    $sys = CountEv 'System' @(6005, 6006, 6008, 41, 1074, 7045, 104, 7034)
    $g = $sys | Group-Object Id
    $det += "System 로그 (최근 $Days일): " + (($g | Sort-Object Name | ForEach-Object { "ID$($_.Name)=$($_.Count)" }) -join ', ')
    $boots = @($sys | Where-Object { $_.Id -eq 6005 })
    if ($boots.Count -gt 0) { $det += "부팅 $($boots.Count)회, 마지막 부팅 $(D $boots[0].TimeCreated)" }
    foreach ($e in ($sys | Where-Object { $_.Id -in 104, 7045, 6008, 41 } | Select-Object -First 30)) { $line = "{0} System ID{1}: {2}" -f (D $e.TimeCreated), $e.Id, (("$($e.Message)" -replace '\s+', ' ').Substring(0, [Math]::Min(100, "$($e.Message)".Length))); $det += $line; if ($e.Id -in 104, 7045) { $flags += $line } }
    # Security (관리자 필요)
    $secOk = $false
    try {
        $sec = @(Get-WinEvent -FilterHashtable @{ LogName = 'Security'; Id = @(4624, 4625, 1102, 4720, 4726, 4732, 4672, 4648); StartTime = $From } -ErrorAction Stop)
        $secOk = $true
    } catch { if ("$_" -match 'No events|이벤트가 없') { $sec = @(); $secOk = $true } else { $det += "Security 로그 조회 불가 (관리자 권한 필요): $_" } }
    if ($secOk) {
        $g = $sec | Group-Object Id
        $det += "Security 로그 (최근 $Days일): " + (($g | Sort-Object Name | ForEach-Object { "ID$($_.Name)=$($_.Count)" }) -join ', ')
        $logons = @($sec | Where-Object { $_.Id -eq 4624 })
        $byType = @{}
        foreach ($l in $logons) { $x = [xml]$l.ToXml(); $lt = ($x.Event.EventData.Data | Where-Object { $_.Name -eq 'LogonType' }).'#text'; $u = ($x.Event.EventData.Data | Where-Object { $_.Name -eq 'TargetUserName' }).'#text'; if ($u -notmatch '\$$|^(SYSTEM|LOCAL SERVICE|NETWORK SERVICE|DWM-|UMFD-|ANONYMOUS)') { $k = "유형$lt/$u"; if ($byType.ContainsKey($k)) { $byType[$k]++ } else { $byType[$k] = 1 } } }
        if ($byType.Count -gt 0) { $det += "로그온 성공(4624) 계정/유형: " + (($byType.GetEnumerator() | Sort-Object Value -Descending | Select-Object -First 15 | ForEach-Object { "$($_.Key)=$($_.Value)" }) -join ', ') }
        $rdpLog = @($byType.Keys | Where-Object { $_ -like '유형10/*' })
        if ($rdpLog.Count -gt 0) { $flags += "원격(RDP) 로그온 있음: " + ($rdpLog -join ', ') }
        $failed = @($sec | Where-Object { $_.Id -eq 4625 })
        if ($failed.Count -gt 0) { $det += "로그온 실패(4625) $($failed.Count)건, 최근 $(D $failed[0].TimeCreated)"; if ($failed.Count -gt $Cfg.FailedLogonThreshold) { $flags += "로그온 실패 $($failed.Count)건 (임계치 $($Cfg.FailedLogonThreshold) 초과)" } }
        foreach ($e in ($sec | Where-Object { $_.Id -in 1102, 4720, 4726, 4732 })) { $line = "{0} Security ID{1}: {2}" -f (D $e.TimeCreated), $e.Id, (("$($e.Message)" -replace '\s+', ' ').Substring(0, [Math]::Min(100, "$($e.Message)".Length))); $det += $line; $flags += $line }
    }
    # 로그 설정 상태
    foreach ($ln in @('Security', 'System', 'Application')) { try { $l = Get-WinEvent -ListLog $ln -ErrorAction Stop; $det += "{0} 로그: 크기 {1:N0}KB / 최대 {2:N0}KB, 기록 {3:N0}건" -f $ln, ($l.FileSize / 1KB), ($l.MaximumSizeInBytes / 1KB), $l.RecordCount } catch {} }
    if ($flags.Count -gt 0) { Add-Result '3-라' '윈도우 이벤트로그 확인' '확인필요' ("주의 이벤트 $($flags.Count)건: " + (($flags | Select-Object -First 3) -join ' / ').Substring(0, [Math]::Min(160, (($flags | Select-Object -First 3) -join ' / ').Length))) (@('--- 주의 이벤트 ---') + $flags + @('--- 요약 ---') + $det) }
    elseif (-not $secOk) { Add-Result '3-라' '윈도우 이벤트로그 확인' '확인불가' 'System 로그 이상 없음, Security 로그는 관리자 권한 부족으로 미확인' $det }
    else { Add-Result '3-라' '윈도우 이벤트로그 확인' '양호' "최근 $Days일 System/Security 로그에 로그삭제·신규서비스·계정생성·과다 로그온실패 없음" $det }
} catch { Add-Fail '3-라' '윈도우 이벤트로그 확인' $_ }

# ------------------------------------------------------------
#  저장
# ------------------------------------------------------------
$stamp = $Now.ToString('yyyyMMdd_HHmm')
$safeUser = ($env:USERNAME -replace '[\\/:*?"<>|]', '_')
$base = Join-Path $OutDir ("pcheck_{0}_{1}_{2}" -f $env:COMPUTERNAME, $safeUser, $stamp)
$Report.meta.summary = [ordered]@{}
foreach ($r in @('양호', '미흡', '확인필요', '확인불가')) { $Report.meta.summary[$r] = @($Report.items.Values | Where-Object { $_.result -eq $r }).Count }

$json = $Report | ConvertTo-Json -Depth 6
[IO.File]::WriteAllText("$base.json", $json, (New-Object System.Text.UTF8Encoding $true))

$txt = New-Object System.Text.StringBuilder
[void]$txt.AppendLine("특허사무소 개인정보처리업무 점검 - 자동수집 요약")
[void]$txt.AppendLine("PC: $($Report.meta.computer)  사용자: $($Report.meta.user)  수집: $($Report.meta.generatedAt)  기간: $($Report.meta.periodFrom)~$($Report.meta.periodTo)  관리자권한: $IsAdmin")
[void]$txt.AppendLine("OS: $($Report.meta.os)  IP: $($Report.meta.ip)")
[void]$txt.AppendLine(('-' * 70))
foreach ($it in $Report.items.Values) { [void]$txt.AppendLine(("[{0}] {1,-4} {2} : {3}" -f $it.id, $it.result, $it.name, $it.summary)) }
[void]$txt.AppendLine(('-' * 70))
foreach ($it in $Report.items.Values) { [void]$txt.AppendLine(""); [void]$txt.AppendLine("## [$($it.id)] $($it.name) - $($it.result)"); foreach ($d in $it.details) { [void]$txt.AppendLine("   $d") } }
[IO.File]::WriteAllText("$base.txt", $txt.ToString(), (New-Object System.Text.UTF8Encoding $true))

# ------------------------------------------------------------
#  QR 페이지 생성 (요약만 압축해서 URL #d= 에 담음)
# ------------------------------------------------------------
try {
    $tplPath = Join-Path $PSScriptRoot 'qr_template.html'
    if ((Test-Path $tplPath) -and $Cfg.ChecklistUrl) {
        function To-Base32([byte[]]$bytes) {
            $A = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567'; $sb = New-Object System.Text.StringBuilder; $bits = 0; $v = [uint64]0
            foreach ($b in $bytes) { $v = (($v -shl 8) -bor $b) -band 0xFFFFFFFFFFFF; $bits += 8; while ($bits -ge 5) { [void]$sb.Append($A[[int](($v -shr ($bits - 5)) -band 31)]); $bits -= 5 } }
            if ($bits -gt 0) { [void]$sb.Append($A[[int](($v -shl (5 - $bits)) -band 31)]) }
            $sb.ToString()
        }
        function Make-Payload([int]$cap) {
            $m = $Report.meta
            $items = [ordered]@{}
            foreach ($it in $Report.items.Values) { $sm = "$($it.summary)"; if ($sm.Length -gt $cap) { $sm = $sm.Substring(0, $cap) + '…' }; $items[$it.id] = @($it.result, $sm) }
            $obj = [ordered]@{ m = [ordered]@{ c = "$($m.computer)"; u = "$($m.user)"; o = "$($m.os)"; i = "$($m.ip)"; g = "$($m.generatedAt)"; f = "$($m.periodFrom)"; t = "$($m.periodTo)"; a = [int][bool]$m.isAdmin; v = "$($m.scriptVersion)" }; i = $items }
            $json = ($obj | ConvertTo-Json -Depth 5 -Compress)
            $ms = New-Object System.IO.MemoryStream
            $ds = New-Object System.IO.Compression.DeflateStream($ms, [System.IO.Compression.CompressionLevel]::Optimal, $true)
            $raw = [System.Text.Encoding]::UTF8.GetBytes($json); $ds.Write($raw, 0, $raw.Length); $ds.Dispose()
            To-Base32 $ms.ToArray()
        }
        $data = $null
        foreach ($cap in @(120, 90, 60, 40, 25, 15)) { $data = Make-Payload $cap; if ($data.Length -le $Cfg.QrMaxChars) { break } }
        $tpl = [IO.File]::ReadAllText($tplPath, [Text.Encoding]::UTF8)
        $sumTxt = "양호 {0} / 미흡 {1} / 확인필요 {2} / 확인불가 {3}" -f $Report.meta.summary['양호'], $Report.meta.summary['미흡'], $Report.meta.summary['확인필요'], $Report.meta.summary['확인불가']
        $html = $tpl.Replace('{{URL}}', $Cfg.ChecklistUrl).Replace('{{DATA}}', $data).Replace('{{PC}}', "$($Report.meta.computer)").Replace('{{USER}}', "$($Report.meta.user)").Replace('{{TIME}}', "$($Report.meta.generatedAt)").Replace('{{SUMMARY}}', $sumTxt)
        [IO.File]::WriteAllText("$base.QR.html", $html, (New-Object System.Text.UTF8Encoding $true))
        W "QR 페이지 저장: $base.QR.html (데이터 $($data.Length)자)"
        if ($Cfg.OpenQrPage) { try { Start-Process "$base.QR.html" } catch {} }
    } else { W "QR 페이지 생략 (qr_template.html 없음 또는 ChecklistUrl 미설정)" }
} catch { W "QR 페이지 생성 실패: $_" }

W "저장 완료: $base.json"
W "결과: 양호 $($Report.meta.summary['양호']) / 미흡 $($Report.meta.summary['미흡']) / 확인필요 $($Report.meta.summary['확인필요']) / 확인불가 $($Report.meta.summary['확인불가'])"
exit 0
