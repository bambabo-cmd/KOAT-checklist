@echo off
setlocal EnableExtensions
title PC Privacy Check (KOAT)
set "PS1=%~dp0collect.ps1"
set "OUT=%~dp0reports"

if not exist "%PS1%" (
  echo [ERROR] collect.ps1 not found next to this bat file.
  pause
  exit /b 1
)

if /i "%~1"=="/elevated" goto :run
if /i "%~1"=="/noelev"   goto :run

rem ---- already admin? ----
net session >nul 2>&1
if %errorlevel%==0 goto :run

rem ---- try UAC elevation (declining is OK: falls back to user rights) ----
echo Requesting administrator rights (for Security event log / Prefetch / Bluetooth registry)...
echo If you click "No", the check still runs with user rights and marks those items as "needs manual check".
powershell -NoProfile -ExecutionPolicy Bypass -Command "try { Start-Process -FilePath '%~f0' -ArgumentList '/elevated' -Verb RunAs -ErrorAction Stop; exit 0 } catch { exit 1 }"
if %errorlevel%==0 exit /b 0
echo.
echo Elevation declined or unavailable. Running with current user rights.
echo.

:run
if not exist "%OUT%" mkdir "%OUT%" >nul 2>&1
rem Unblock files copied from the internet (Mark of the Web) - harmless if it fails
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-ChildItem -LiteralPath '%~dp0' -Filter *.ps1 | Unblock-File -ErrorAction SilentlyContinue" >nul 2>&1

powershell -NoProfile -ExecutionPolicy Bypass -InputFormat None -File "%PS1%" -OutDir "%OUT%" -Days 30
set "RC=%errorlevel%"
echo.
if "%RC%"=="0" (
  echo Done. Report files are in: %OUT%
  echo Drag the .json file onto the HTML checklist to auto-fill it.
) else (
  echo Finished with warnings (code %RC%). Check the messages above and the reports folder.
)
echo.
pause
exit /b %RC%
