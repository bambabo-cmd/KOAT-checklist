[폴더 구성 - 이 폴더 전체를 USB에 복사]
 run_check.bat          점검대상 PC에서 더블클릭 (관리자 승인 안 해도 실행됨)
 collect.ps1           수집 스크립트. 상단 $Cfg 에서 키워드/체크리스트 주소 수정
 qr_template.html      QR 페이지 틀 (건드릴 필요 없음)
 checklist.html (= index.html, GitHub 업로드용)    체크리스트 양식 (PC 브라우저에서 열거나, GitHub Pages 등에 올려서 사용)
 reports\              실행 결과가 여기 생김:
                        pcheck_PC명_사용자_일시.json   전체 결과 (체크리스트에 끌어다 놓기용)
                        pcheck_..._.txt                사람이 읽는 요약+상세
                        pcheck_..._.QR.html            아이패드로 찍는 QR (자동으로 열림)

[현장 순서 - 아이패드 QR 방식 (권장)]
 1. 대상 PC에 USB 꽂고 run_check.bat 실행 → 끝나면 QR 페이지가 브라우저에 자동으로 뜸
 2. 아이패드 카메라 앱으로 QR 촬영 → 링크 탭 → 체크리스트가 결과 채워진 상태로 열림
 3. 확인·수정, 담당자 서명 → "PDF 저장 / 인쇄" (공유 → 프린트 → 핀치아웃 → 파일에 저장)
    ※ QR에는 항목별 결과+요약만 담김. 도메인/파일/USB 상세는 reports\*.txt 참조

[체크리스트 호스팅 주소]
 collect.ps1 의 ChecklistUrl = 'https://bambabo-cmd.github.io/KOAT-checklist/'
 (GitHub Pages, 로그인 불필요. 양식 수정 시 저장소의 index.html 만 교체) 결과 데이터는 주소 뒤 #d= 에만 있고 서버로 전송되지 않음.

[대안 - QR 없이]
 - USB-C 아이패드: USB를 직접 꽂고 파일 앱에서 reports\*.json 을 Safari 체크리스트 페이지에 드래그
 - 메일: *.json 첨부 → 아이패드에서 "파일에 저장" → 체크리스트 "점검결과 파일 열기"
 - PC에서 바로: checklist.html (= index.html, GitHub 업로드용) 을 크롬/엣지로 열고 json 드래그 → 마우스로 서명 → PDF 저장

[이어서 작성]
 "작성내용 저장"(.form.json) → 다른 기기/다음날 "작성내용 불러오기"
 담당자 정보는 표 위 "현재 담당자 정보를 기본값으로 저장" 으로 기기에 저장됨
